import java.awt.*;
import java.awt.event.*;

public class FenetreBonjour2 extends Frame implements ActionListener{
	private static final int LARGEUR=1000;
	private static final int HAUTEUR=800;
	private Button boutonFin;
	private Button bPink;
	private Button bYellow;
	private Label text;
	// Constructeur & associés
	public FenetreBonjour2(){
		text=new Label("Bonjour à tous !!! :þ",1);
		setSize(LARGEUR,HAUTEUR);
		setVisible(true);
		setTitle("Yourface !!!");
		setBackground(Color.decode("#ff0000"));
		setForeground(Color.decode("#05120A"));
		setLayout(new BorderLayout());
		boutonFin = new Button("Jean Nez Mhar, Sam et Nerve ! :þ");
		boutonFin.addActionListener(this);
		add(boutonFin, BorderLayout.NORTH);
		this.pinkButton();
		this.yellowButton();
		add(text);
	}
	//associés au constructeur
	private void yellowButton(){
		bYellow = new Button("Ce bouton n'est pas jaune");
		add(bYellow, BorderLayout.EAST);
		bYellow.addActionListener(this);
	}
	private void pinkButton(){
		bPink = new Button("Ce bouton n'est pas rose.");
		add(bPink, BorderLayout.WEST);
		bPink.addActionListener(this);
	}
	
	
	
	public void Cacher(){
		setVisible(false);
	}
	public void actionPerformed(ActionEvent e){
		if (e.getSource()==boutonFin){
			System.exit(0);
		} else if (e.getSource()==bYellow){
			setBackground(Color.decode("#fef418"));
			text.setText("Et voila, le fond est jaune !");
			this.repaint();
		} else if (e.getSource()==bPink){
			setBackground(Color.decode("#ffc0e4"));
			text.setText("J'aime le chocolat rose...");
			this.repaint();
		}
	}
}
