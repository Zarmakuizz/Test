public class Main{
	public static void main(String[] args){
		FenetreBonjour5 jeLeDis = new FenetreBonjour5();
//		jeLeDis.Cacher();
	}
}
