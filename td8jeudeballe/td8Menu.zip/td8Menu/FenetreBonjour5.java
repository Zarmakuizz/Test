import java.awt.*;
import java.awt.event.*;

public class FenetreBonjour5 extends Frame {
	private static final int LARGEUR=400;
	private static final int HAUTEUR=200;
	private Label text;
	private MenuBar barre;
	private Menu mGestion;
	private Menu mCouleur;
	private MenuItem iPink;
	private MenuItem iYellow;
	private MenuItem iGreen;
	private MenuItem iBlue;
	private MenuItem iQuit;
	// Constructeur & associés
	public FenetreBonjour5(){
		addWindowListener(new WindowAdapter(){ public void windowClosing(WindowEvent e){ System.exit(0);}});
		text=new Label("     Bonjour à tous !!! :þ     ",1);
		barre= new MenuBar();
		mGestion= new Menu("Gestion");
		mCouleur= new Menu("Couleurs");
		iPink=new MenuItem("Colorer en rose");
		iYellow=new MenuItem("Colorer en jaune");
		iGreen=new MenuItem("Colorer en vert");
		iBlue=new MenuItem("Colorer en bleu");
		iQuit=new MenuItem("Quitter");
		iPink.addActionListener(new ActionCouleur(Color.decode("#fe9fb0"), this));
		iYellow.addActionListener(new ActionCouleur(Color.decode("#ffff00"), this));
		iGreen.addActionListener(new ActionCouleur(Color.decode("#00ff00"), this));
		iBlue.addActionListener(new ActionCouleur(Color.decode("#1e90ff"), this));
		iQuit.addActionListener(new ActionQuitter());
		mGestion.add(iQuit);
		mCouleur.add(iYellow);
		mCouleur.add(iPink);
		mCouleur.add(iGreen);
		mCouleur.add(iBlue);
		setSize(LARGEUR,HAUTEUR);
		setVisible(true);
		setTitle("Restauration Fast-Fat !!!");
		barre.add(mGestion);
		barre.add(mCouleur);
		setBackground(Color.decode("#ff0000"));
		setForeground(Color.decode("#05120A"));
		setLayout(new BorderLayout());
		setMenuBar(barre);
		add(text);
//		pack();
	}
	//associés au constructeur
	
	public void Cacher(){
		setVisible(false);
	}
	
}

class ActionQuitter implements ActionListener {
	public void actionPerformed(ActionEvent e){
		System.exit(0);
	}
}
class ActionCouleur implements ActionListener {
	private Color color;
	private Frame frame;
	private Label text;
	public ActionCouleur(Color couleur, Frame fenetre){
		color=couleur;
		frame=fenetre;
	}
	public void actionPerformed(ActionEvent e){
		frame.setBackground(color);
		frame.repaint();
	}
}


