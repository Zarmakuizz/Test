import java.awt.*;
import java.awt.event.*;

public class FenetreBonjour4 extends Frame implements ActionListener{
	private Button boutonFin;
	private Button bPink;
	private Button bYellow;
	private Label text;
	private Panel centre;
	private Panel droite;
	// Constructeur & associés
	public FenetreBonjour4(){
		text=new Label("     Bonjour à tous !!! :þ     ",1);
		centre = new Panel();
		droite = new Panel();
		setVisible(true);
		setTitle("Yourface !!!");
		setBackground(Color.decode("#ff0000"));
		setForeground(Color.decode("#05120A"));
		setLayout(new BorderLayout());
		centre.setLayout(new FlowLayout());
		droite.setLayout(new GridLayout(4,1));
		boutonFin = new Button("Jean Nez Mhar, Sam et Nerve ! :þ");
		boutonFin.addActionListener(this);
		centre.add(text);
		this.pinkButton();
		this.yellowButton();
		centre.add(droite);
		add(centre, BorderLayout.NORTH);
		add(boutonFin, BorderLayout.SOUTH);
		pack();
	}
	//associés au constructeur
	private void yellowButton(){
		bYellow = new Button("Ce bouton n'est pas jaune");
		droite.add(bYellow);
		bYellow.addActionListener(this);
	}
	private void pinkButton(){
		bPink = new Button("Ce bouton n'est pas rose.");
		droite.add(bPink);
		bPink.addActionListener(this);
	}
	
	
	public void Cacher(){
		setVisible(false);
	}
	public void actionPerformed(ActionEvent e){
		if (e.getSource()==boutonFin){
			System.exit(0);
		} else if (e.getSource()==bYellow){
			setBackground(Color.decode("#fef418"));
			text.setText("Et voila, le fond est jaune !");
			this.repaint();
		} else if (e.getSource()==bPink){
			setBackground(Color.decode("#ffc0e4"));
			text.setText("J'aime le chocolat rose...");
			this.repaint();
		}
	}
}
